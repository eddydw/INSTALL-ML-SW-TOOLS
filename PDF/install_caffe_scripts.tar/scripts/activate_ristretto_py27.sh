echo ""
echo "VIRTUALENV WITH Caffe Ristretto, PYTHON2.7, CUDA-8.0 cuDNN-7.0.5, TENSORFLOW-GPU 1.4.1 DECENT"
echo ""

source ~/.bashrc


# caffe tools
export CAFFE_ROOT=/home/root2/caffe_tools/Ristretto
export LD_LIBRARY_PATH=$CAFFE_ROOT/distribute/lib:$LD_LIBRARY_PATH
export PYTHONPATH=$CAFFE_ROOT/distribute/python:$PYTHONPATH
       
# enter the virtualenv
workon ristretto_py27

