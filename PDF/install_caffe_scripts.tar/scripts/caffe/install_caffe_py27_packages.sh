# packages needed by BVLC CAFFE 1.0
# execute from Python2.7 virtualenv

sudo apt-get update
sudo apt-get upgrade

sudo apt-get install build-essential cmake git unzip pkg-config
sudo apt-get install libjpeg-dev libtiff5-dev libjasper-dev libpng12-dev
sudo apt-get install libavcodec-dev libavformat-dev libswscale-dev libv4l-dev
sudo apt-get install libxvidcore-dev libx624-dev
sudo apt-get install libxvidcore-dev libx264-dev
sudo apt-get install libgtk-3-dev
sudo apt-get install libhdf5-serial-dev graphviz
sudo apt-get install libopenblas-dev libatlas-base-dev gfortran
sudo apt-get install python2.7-dev python3-dev
sudo apt-get install linux-image-generic linux-image-extra-virtual
sudo apt-get install linux-source linux-headers-generic
sudo apt-get install libglu1-mesa libxi-dev libxmu-dev libglu1-mesa-dev
sudo apt-get install --no-install-recommends libboost-all-dev

sudo apt-get install -y build-essential
sudo apt-get install -y cmake
sudo apt-get install -y git
sudo apt-get install -y pkg-config
sudo apt-get install -y libprotobuf-dev
sudo apt-get install -y libleveldb-dev
sudo apt-get install -y libsnappy-dev
sudo apt-get install -y libhdf5-serial-dev
sudo apt-get install -y protobuf-compiler
sudo apt-get install -y libatlas-base-dev
sudo apt-get install -y libgflags-dev
sudo apt-get install -y libgoogle-glog-dev
sudo apt-get install -y liblmdb-dev
sudo apt-get install python-pip
sudo apt-get install python-dev
sudo apt-get install python-numpy
sudo apt-get install python-scipy
sudo apt-get install python-opencv
sudo apt-get install python-lmdb
sudo apt-get install libopencv-dev

#cp ~/scripts/caffe/test_layer_factory.cpp  $CAFFE_ROOT/src/caffe/test/test_layer_factory.cpp 
