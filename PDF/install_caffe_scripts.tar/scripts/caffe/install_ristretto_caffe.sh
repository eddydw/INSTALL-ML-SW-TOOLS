# set manually these 2 variables

export CAFFE_ROOT=~/caffe_tools/Ristretto
export MYVENV=ristretto_py27


#########################################################################
# clone Ristretto caffe from github
#########################################################################
cd ~/Downloads
git clone https://github.com/pmgysel/caffe
#mkdir ~/caffe_tools
mv ~/Downloads/caffe ~/caffe_tools/Ristretto

#########################################################################
# copy the correct .bashrc file
#########################################################################
# save your original .bashrc file
cp ~/.bashrc ~/.orig_bashrc
# copy my .bashrc file
cp ~/scripts/caffe/.bashrc ~/


#########################################################################
# install all the packges needed by Caffe itself
# (only once: if you install a second fork of caffe you do not need to install it twice)
#########################################################################

source ~/scripts/caffe/install_caffe_py27_packages.sh


#########################################################################
#########################################################################
# leave ALL the remaining lines below unchanged!
#########################################################################
#########################################################################


#########################################################################
#create python2.7 virtual environment
########################################################################
cd ~
mkvirtualenv $MYVENV -p python2
workon $MYVENV

# install all the packages needed in the virtual env, which are compatible also with Caffe
pip2 install -r ~/scripts/caffe/caffe_py27_requirements.txt

# patch for opencv 2.x
cd ~/.virtualenvs/$MYVENV/local/lib/python2.7/site-packages/
ln -s /usr/lib/python2.7/dist-packages/cv2.x86_64-linux-gnu.so cv2.so
cd ~

#########################################################################
# now compile caffe
#########################################################################

cd $CAFFE_ROOT
#cp Makefile orig_makefile
#cp Makefile.config orig_Makefile.config
cp ~/scripts/caffe/Makefile .
cp ~/scripts/caffe/Makefile.config .
#cp ~/scripts/caffe/test_layer_factory.cpp  ./src/caffe/test/test_layer_factory.cpp

make clean
make all  -j8
make test -j8
make pycaffe
make distribute
make runtest -j8


#########################################################################
# now test everything
#########################################################################
source ~/scripts/activate_ristretto_py27.sh

echo $CAFFE_ROOT
echo $LD_LIBRARY_PATH
echo $PYTHONPATH
python ~/scripts/caffe/test_caffe.py




